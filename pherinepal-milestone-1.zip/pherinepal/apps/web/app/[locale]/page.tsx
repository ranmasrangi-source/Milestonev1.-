import Link from 'next/link';
import { getDict } from '@/lib/i18n';
import { first, localizedHref, resolveLocale, resolveLocation, type SearchParams } from '@/lib/route';
import { getPublicCatalog, groupEntries } from '@/lib/catalog';
import { CategoryCard } from '@/components/CategoryCard';
import { LocationSwitcher } from '@/components/LocationSwitcher';
import { SampleNotice } from '@/components/SampleNotice';
import { StatusSummary } from '@/components/StatusSummary';

interface HomePageProps {
  params: { locale: string };
  searchParams: SearchParams;
}

export default function HomePage({ params, searchParams }: HomePageProps) {
  const locale = resolveLocale(params.locale);
  const t = getDict(locale);
  const location = resolveLocation(first(searchParams.location));
  const entries = getPublicCatalog(location.code);
  const sections = groupEntries(entries);

  return (
    <>
      <section className="hero">
        <div className="container hero__inner">
          <p className="eyebrow">{t.tagline}</p>
          <h1 className="hero__title">{t.heroTitle}</h1>
          <p className="hero__body">{t.heroBody}</p>

          <form action={localizedHref(locale, '/services')} method="get" role="search" className="hero__search">
            <label htmlFor="hero-q" className="visually-hidden">
              {t.searchLabel}
            </label>
            <input id="hero-q" name="q" type="search" placeholder={t.searchPlaceholder} className="input" />
            <input type="hidden" name="location" value={location.code} />
            <button className="btn btn--primary" type="submit">
              {t.searchButton}
            </button>
          </form>

          <div className="hero__actions">
            <Link className="btn btn--ghost" href={localizedHref(locale, '/services', { location: location.code })}>
              {t.ctaBrowse}
            </Link>
            <Link className="btn btn--ghost" href={localizedHref(locale, '/services/trip-planning', { location: location.code })}>
              {t.ctaPlan}
            </Link>
            <Link
              className="btn btn--ghost"
              href={localizedHref(locale, '/services', { status: 'partner_registration_open' })}
            >
              {t.ctaPartner}
            </Link>
          </div>
        </div>
      </section>

      <section className="section container" aria-labelledby="location-heading">
        <h2 id="location-heading" className="section__title">
          {t.pickLocation}
        </h2>
        <LocationSwitcher locale={locale} t={t} basePath="" currentCode={location.code} />
        <StatusSummary entries={entries} locale={locale} t={t} />
      </section>

      <section className="section container" id="services" aria-labelledby="services-heading">
        <div className="section__head">
          <h2 id="services-heading" className="section__title">
            {t.groupsTitle}
          </h2>
          <p className="muted">
            {t.statusIntro}: {location.name[locale]}
          </p>
        </div>
        {sections.map((section) => (
          <div key={section.group} className="service-group">
            <h3 className="service-group__title">{t.groupLabels[section.group]}</h3>
            <div className="card-grid">
              {section.items.map((entry) => (
                <CategoryCard key={entry.category.code} entry={entry} locale={locale} t={t} />
              ))}
            </div>
          </div>
        ))}
      </section>

      <section className="section container" aria-label={t.trustTitle}>
        <div className="two-col">
          <article className="card">
            <h2 className="card__title">{t.trustTitle}</h2>
            <p>{t.trustBody}</p>
          </article>
          <article className="card">
            <h2 className="card__title">{t.safetyTitle}</h2>
            <p>{t.safetyBody}</p>
            <Link className="btn btn--ghost" href={localizedHref(locale, '/services/sos')}>
              {t.navSafety}
            </Link>
          </article>
        </div>
        <SampleNotice t={t} />
      </section>
    </>
  );
}
