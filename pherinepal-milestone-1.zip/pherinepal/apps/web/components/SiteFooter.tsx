import type { Dict } from '@/lib/i18n';

export function SiteFooter({ t }: { t: Dict }) {
  return (
    <footer className="site-footer">
      <div className="container">
        <p className="site-footer__promise">{t.promise}</p>
        <p className="muted">{t.footerNote}</p>
        <p className="muted">{t.legalPending}</p>
      </div>
    </footer>
  );
}
