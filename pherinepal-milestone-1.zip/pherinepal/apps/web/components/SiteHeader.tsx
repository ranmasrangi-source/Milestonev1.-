import Link from 'next/link';
import type { Dict, Locale } from '@/lib/i18n';
import { localizedHref } from '@/lib/route';
import { LanguageSwitcher } from './LanguageSwitcher';

interface SiteHeaderProps {
  locale: Locale;
  t: Dict;
}

export function SiteHeader({ locale, t }: SiteHeaderProps) {
  return (
    <header className="site-header">
      <div className="container site-header__inner">
        <Link href={localizedHref(locale, '')} className="brand">
          <span className="brand__mark" aria-hidden="true">
            ▲
          </span>
          <span className="brand__name">{t.siteName}</span>
        </Link>
        <nav aria-label={t.navPrimary} className="site-nav">
          <ul>
            <li>
              <Link href={localizedHref(locale, '')}>{t.navHome}</Link>
            </li>
            <li>
              <Link href={localizedHref(locale, '/services')}>{t.navServices}</Link>
            </li>
            <li>
              <Link href={localizedHref(locale, '/services/trip-planning')}>{t.navPlan}</Link>
            </li>
            <li>
              <Link href={localizedHref(locale, '/services/sos')}>{t.navSafety}</Link>
            </li>
          </ul>
        </nav>
        <LanguageSwitcher locale={locale} label={t.switchLabel} />
      </div>
    </header>
  );
}
