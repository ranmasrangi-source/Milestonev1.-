import Link from 'next/link';
import type { CatalogEntry } from '@pherinepal/domain';
import type { Dict, Locale } from '@/lib/i18n';
import { localizedHref } from '@/lib/route';
import { StatusBadge } from './StatusBadge';

interface CategoryCardProps {
  entry: CatalogEntry;
  locale: Locale;
  t: Dict;
}

export function CategoryCard({ entry, locale, t }: CategoryCardProps) {
  const { category, location, status } = entry;
  const headingId = `svc-${category.code}`;

  return (
    <article className="card service-card" aria-labelledby={headingId}>
      <div className="service-card__top">
        <StatusBadge status={status} locale={locale} />
      </div>
      <h3 id={headingId} className="service-card__title">
        {category.name[locale]}
      </h3>
      <p className="service-card__text">{category.description[locale]}</p>
      <div className="service-card__footer">
        <Link
          className="btn btn--ghost"
          href={localizedHref(locale, `/services/${category.code}`, { location: location.code })}
        >
          {t.learnMore}
          <span className="visually-hidden">: {category.name[locale]}</span>
        </Link>
      </div>
    </article>
  );
}
