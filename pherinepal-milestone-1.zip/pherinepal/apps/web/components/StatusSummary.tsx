import { SERVICE_STATUSES, type CatalogEntry, type ServiceStatus } from '@pherinepal/domain';
import type { Dict, Locale } from '@/lib/i18n';
import { StatusBadge } from './StatusBadge';

interface StatusSummaryProps {
  entries: CatalogEntry[];
  locale: Locale;
  t: Dict;
}

export function StatusSummary({ entries, locale, t }: StatusSummaryProps) {
  const counts = new Map<ServiceStatus, number>();
  for (const entry of entries) {
    counts.set(entry.status, (counts.get(entry.status) ?? 0) + 1);
  }

  return (
    <div className="status-summary">
      <h3 className="status-summary__title">{t.summaryTitle}</h3>
      <ul className="status-summary__list">
        {SERVICE_STATUSES.map((status) => (
          <li key={status}>
            <StatusBadge status={status} locale={locale} />
            <span className="status-summary__count" aria-label={`${counts.get(status) ?? 0}`}>
              {counts.get(status) ?? 0}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
