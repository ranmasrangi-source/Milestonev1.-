# PheriNepal

Your Complete Nepal Travel Companion.
*Before You Go. While You Explore. After You Return. PheriNepal Is With You.*

This is the **Milestone 1** foundation: repository structure, design system, a responsive
bilingual (English and Nepali) homepage, a public service catalogue that shows every planned
service from day one, location-based service statuses, the database foundation, and a master
progress tracker.

**Booking, payments, SOS dispatch and all external integrations are disabled.** Nothing in
this build takes a real booking, payment or emergency request.

---

## 1. Requirements

| Tool | Version | Notes |
|---|---|---|
| Node.js | 20.11 or later | `.nvmrc` pins 20. Milestone 1 was executed on Node 22. |
| npm | 10 or later | Ships with Node 20 |
| PostgreSQL | 13 or later | Optional for Milestone 1. Needed only for migrations and seeding |

## 2. Quick start (no database needed)

```bash
# from the repository root
npm install
npm run dev
```

Open http://localhost:3000. The root redirects to `/en`. Switch to Nepali with the
**नेपाली** link in the header, or open http://localhost:3000/ne.

## 3. Verify the build

```bash
npm test           # domain unit tests (30 tests)
npm run typecheck  # TypeScript for domain and web
npm run build      # production build of the web app
npm start          # serves the production build on port 3000
```

Health check: `GET /api/v1/health`. Catalogue API: `GET /api/v1/catalog?location=pokhara`.

## 4. Optional: database setup (preparation for Milestone 2)

```bash
export DATABASE_URL="postgres://USER:PASSWORD@localhost:5432/pherinepal_dev"
npm run db:migrate   # applies packages/db/migrations/*.sql in order
npm run db:seed      # loads sample categories, locations and statuses
```

`db:seed` refuses to run when `NODE_ENV=production` unless `ALLOW_SAMPLE_SEED=true` is set.
Use it only on a non-production database. Re-running the seed is safe: existing statuses are
never overwritten.

Milestone 1 pages read the in-repo sample data, so the database is not needed to run the site.
The database-backed data source arrives in Milestone 2.

## 5. Environment variables

Copy `.env.example` to `apps/web/.env.local` for local work. Never commit real values.

| Variable | Default | Purpose |
|---|---|---|
| `NEXT_PUBLIC_SITE_URL` | `http://localhost:3000` | Canonical links and metadata |
| `BOOKING_ENABLED` | `false` | Booking master switch. **Turning it on alone does not open booking.** Every category and location also needs status `available`, an enabled booking mode, and a complete readiness record with two approvers. |
| `SOS_PUBLIC_ENABLED` | `false` | Reserved for the SOS milestone. Not read yet. |
| `DATABASE_URL` | empty | PostgreSQL connection for migrations and seeding |
| `ALLOW_SAMPLE_SEED` | `false` | Permits sample seed in production. Do not set in production. |

## 6. Repository layout

```
pherinepal/
├── apps/
│   └── web/                        Next.js 14 app (App Router, TypeScript)
│       ├── app/
│       │   ├── globals.css         Design tokens and base styles (mobile-first)
│       │   ├── [locale]/           en and ne routes
│       │   │   ├── page.tsx                       Homepage
│       │   │   ├── services/page.tsx              Catalogue with filters
│       │   │   └── services/[category]/page.tsx   Category and status page
│       │   └── api/v1/             catalogue and health endpoints
│       ├── components/             Reusable UI (status badge, cards, switchers)
│       └── lib/                    i18n, routing, catalogue adapter, SEO policy
├── packages/
│   ├── domain/                     Framework-independent business rules (tested)
│   │   └── src/                    statuses, categories, locations, readiness,
│   │                               booking gate, catalogue builder, sample data
│   └── db/
│       ├── migrations/             SQL migrations (0001_foundation.sql)
│       └── scripts/                migrate.mjs, seed.ts
└── docs/
    ├── PROGRESS.md                 Master feature tracker (read this first)
    ├── ARCHITECTURE.md             Layers, rules and extension points
    ├── DECISIONS.md                FINAL / RECOMMENDED / PENDING register
    └── TEST_REPORT.md              What was executed and what was not
```

## 7. How service status works

1. Every planned category (31 in Milestone 1) appears on the public site from day one.
2. Each category has one status per location. A category can be Available in one location and Coming Soon in another.
3. If no status row exists, the service is treated as **Coming Soon**. It is never treated as open.
4. A booking is accepted only when **all** of these hold: the global switch is on, the category is transactional, the status is `available`, the requested mode is enabled, and the readiness record is complete with two distinct approvers. Payment success never confirms a booking on its own.

The gate lives in `packages/domain/src/booking-gate.ts` and is covered by tests.

## 8. Adding a service category or location

1. Add an entry to `packages/domain/src/categories.ts` or `locations.ts`, in both languages.
2. Add the matching database change as a **new** migration file. Never edit a migration that has already been applied.
3. Add or update sample status rows in `sample-data.ts` if needed.
4. Run `npm test`. The taxonomy tests check uniqueness, bilingual text and valid references.

## 9. Known limitations in Milestone 1

- Pages read in-repo sample data, not the database.
- Admin tools to change statuses do not exist yet (Milestone 2).
- The Notify Me form is shown but disabled. No consent is collected or stored yet.
- The partner registration button is disabled. The form arrives in Milestone 3.
- Nepali text is a first draft and needs review by a native speaker.
- Only the light theme is implemented.
- No authentication, customer accounts or partner accounts yet.
- See `docs/TEST_REPORT.md` for the exact list of what was and was not executed.

## 10. Troubleshooting

- **`npm install` fails:** check the Node version. The project targets Node 20.11 or later.
- **Nepali characters look wrong:** install a Devanagari font such as Noto Sans Devanagari, or use a device that includes Nirmala UI (Windows 10 or later).
- **`npm run db:migrate` says DATABASE_URL is not set:** export the variable in the same shell (see section 4).
- **A category shows "Booking is not open":** this is expected. See section 7.

## 11. Ownership

Proprietary. All rights reserved by the project owner. The company is not yet registered. See `docs/DECISIONS.md`.
